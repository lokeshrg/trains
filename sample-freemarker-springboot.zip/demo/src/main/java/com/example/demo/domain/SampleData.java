package com.example.demo.domain;

public class SampleData {

	public String name;
	public String description;
	
	public SampleData(String name, String description){
		this.name = name;
		this.description = description;
	}
}
